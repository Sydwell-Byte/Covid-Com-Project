const express = require('express');
const app = express();

app.use(express.json());

var symptoms = new Array(3);
symptoms[0] = "No Symptoms";
symptoms[1] = "Fever";
symptoms[2] = "Shortness of breath";
symptoms[3] = "Persistent of cough";


let ScreenData = [
  {name :'John',phoneNo : 0712321321 ,symptom : symptoms[0] ,ContactIn14Days : 0 ,ContactAfterCovid : 0 ,LikelyPositive : 0},
  {name :'Thabang',phoneNo : 0712321321 ,symptom : symptoms[2] ,ContactIn14Days : 1 ,ContactAfterCovid : 1 ,LikelyPositive : 0},
  {name :'Lerato',phoneNo : 0712321321 ,symptom : symptoms[1] ,ContactIn14Days : 1 ,ContactAfterCovid : 0 ,LikelyPositive : 0}
];


app.get('/',(reg,res)=>{
  res.send('COVID Compliance Screening Rest Services')
});

app.get('api/get/:name',(reg,res)=>{
  
  const data = ScreenData.find(c => c.name == reg.params.name);

  if(!data)
   return res.status(404).send('There is no record found for ${reg.params.name} ');
  else
   return res.send(data);
});

app.get('api/get',(reg,res)=>{
    res.send(ScreenData);
  });

app.get('api/get/:year/:month',(reg,res)=>{
    res.send(reg.params.id)
  });

  app.post('api/post',(reg,res)=>{
    
  
    const data = reg.body;
    if(!data) return res.status(400).send('Bad request ${reg.body} ');

    

    ScreenData.push(data);
    res.send(data);
  });
  app.get('api/get/:symptoms',(reg,res)=>{
  
    const data = ScreenData.find(c => c.symptoms.lenth == reg.params.symptoms.lenth);
  
    if(!data)
     return res.status(404).send('There is no record found for ${reg.params.symptoms} ');
    else
     return res.send(data);
  });

const port = process.env.port || 4000;
app.listen(port,()=>console.log(`Listening port ${port}`));
